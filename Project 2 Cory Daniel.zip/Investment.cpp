#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
//Declare variables for input
float initInv, monDep, AnuInt, years, months;

//total amount input
float totalAm;

//to store interest and year end interest
float intAmt, yearTotInt;

//Display for the user
cout << "*************************\n";

cout << "********Data Input*******\n";

cout << "Initial Investment Amount: \n";
cout << "Monthly Deposit: \n";
cout << "Annual Interest: \n";
cout << "Number of years: \n";

//To get press any key to continue line
system("PAUSE");

//Get data from user
cout << "*************************\n";
cout << "********Data Input*******\n";
cout << "Initial Investment Amount: ";
cin >> initInv;
cout << "Monthly Deposit: ";
cin >> monDep;
cout << "Annual Interest: ";
cin >> AnuInt;
cout << "Number of years: ";
cin >> years;
months = years * 12;

system("PAUSE");

//Set totalAm = initInv
totalAm = initInv;

//Display year data without monthly deposits (important to note)
cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
cout << "==============================================================\n";
cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
cout << "--------------------------------------------------------------\n";
for(int i=0; i<years ;i++){

// yearly interest
intAmt = (totalAm) * ((AnuInt/100));

// year end total
totalAm = totalAm + intAmt;

//Set fixed to only 2 decimal places
cout << (i+1) << "\t\t" << fixed << setprecision(2) << totalAm << "\t\t\t" << intAmt << "\n";

}

//For monthly
totalAm = initInv;

//Display year data with monthly deposits
cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
cout << "==============================================================\n";
cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
cout << "--------------------------------------------------------------\n";
for(int i=0; i<years ;i++){

//Set interest to zero for year
yearTotInt = 0;
for(int j=0; j<12; j++){

//Calculate monthly interest
intAmt = (totalAm + monDep) * ((AnuInt/100)/12);

//Calculate month end interest
yearTotInt = yearTotInt + intAmt;

//Calculate month end total
totalAm = totalAm + monDep + intAmt;
}
cout << (i+1) << "\t\t" << fixed << setprecision(2) << totalAm << "\t\t\t" << yearTotInt << "\n";


}

return 0;
}
